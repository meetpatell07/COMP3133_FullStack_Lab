import { InputFormatDirective } from './input-format.directive';

describe('InputFormatDirective', () => {
  it('should create an instance', () => {
    const directive = new InputFormatDirective();
    expect(directive).toBeTruthy();
  });
});
